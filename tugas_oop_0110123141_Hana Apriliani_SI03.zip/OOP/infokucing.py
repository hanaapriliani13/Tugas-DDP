from kucing import *

micky = kucing('micky', 'coklat', '1thn')

micky.data_kucing()